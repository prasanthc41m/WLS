import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.kirigami as Kirigami

Kirigami.FormLayout {
    id: root

    property alias cfg_phoneIp:       phoneIpField.text
    property alias cfg_phonePort:     phonePortSpin.value
    property alias cfg_enabled:       enabledCheck.checked
    property alias cfg_nightMode:     nightModeCheck.checked
    property alias cfg_nightCap:      nightCapSpin.value
    property alias cfg_minBrightness: minBrightSpin.value
    property alias cfg_maxBrightness: maxBrightSpin.value
    property alias cfg_luxMax:        luxMaxSpin.value
    property alias cfg_gamma:         gammaSpin.value

    // Display target handled separately (ComboBox needs index mapping)
    property string cfg_targetDisplay: "all"

    // ── Phone connection ────────────────────────────────────────────────────
    Item { Kirigami.FormData.isSection: true; Kirigami.FormData.label: "📱 Phone Connection" }

    RowLayout {
        Kirigami.FormData.label: "IP Address:"
        QQC2.TextField {
            id: phoneIpField
            placeholderText: "192.168.1.x"
            Layout.preferredWidth: 160
        }
        QQC2.Label { text: "  Port:" }
        QQC2.SpinBox {
            id: phonePortSpin
            from: 1024; to: 65535; value: 8080
        }
    }

    // ── Display ─────────────────────────────────────────────────────────────
    Item { Kirigami.FormData.isSection: true; Kirigami.FormData.label: "🖥️ Display" }

    QQC2.ComboBox {
        id: displayCombo
        Kirigami.FormData.label: "Control:"
        model: ["All displays", "display0  (NVIDIA / external)", "display1  (Built-in / laptop)"]
        property var values: ["all", "display0", "display1"]

        currentIndex: {
            var idx = values.indexOf(cfg_targetDisplay)
            return idx >= 0 ? idx : 0
        }

        onCurrentIndexChanged: {
            cfg_targetDisplay = values[currentIndex]
        }
    }

    // ── Behaviour ───────────────────────────────────────────────────────────
    Item { Kirigami.FormData.isSection: true; Kirigami.FormData.label: "⚙️ Behaviour" }

    QQC2.CheckBox {
        id: enabledCheck
        Kirigami.FormData.label: "Auto-adjust:"
        text: "Enable automatic brightness"
    }

    QQC2.CheckBox {
        id: nightModeCheck
        Kirigami.FormData.label: "Night mode:"
        text: "Cap brightness at night"
    }

    QQC2.SpinBox {
        id: nightCapSpin
        Kirigami.FormData.label: "Night cap:"
        from: 5; to: 60; value: 40
        textFromValue: function(v) { return v + "%" }
        enabled: nightModeCheck.checked
    }

    // ── Brightness range ────────────────────────────────────────────────────
    Item { Kirigami.FormData.isSection: true; Kirigami.FormData.label: "🔆 Brightness Range" }

    RowLayout {
        Kirigami.FormData.label: "Range:"
        QQC2.Label { text: "Min" }
        QQC2.SpinBox {
            id: minBrightSpin
            from: 1; to: 50; value: 10
            textFromValue: function(v) { return v + "%" }
        }
        QQC2.Label { text: "  Max" }
        QQC2.SpinBox {
            id: maxBrightSpin
            from: 50; to: 100; value: 100
            textFromValue: function(v) { return v + "%" }
        }
    }

    // ── Lux calibration ─────────────────────────────────────────────────────
    Item { Kirigami.FormData.isSection: true; Kirigami.FormData.label: "💡 Lux Calibration" }

    RowLayout {
        Kirigami.FormData.label: "100% at:"
        QQC2.SpinBox {
            id: luxMaxSpin
            from: 50; to: 20000; stepSize: 50; value: 1000
            textFromValue: function(v) { return v + " lux" }
        }
        QQC2.Label {
            text: "  dim≈200 · office≈500 · bright≈1000"
            opacity: 0.7
            font.pointSize: Kirigami.Theme.smallFont.pointSize
        }
    }

    RowLayout {
        Kirigami.FormData.label: "Gamma:"
        QQC2.SpinBox {
            id: gammaSpin
            from: 5; to: 30; stepSize: 1; value: 12
            // Store as x10 to avoid floats; WLS.py divides by 10
            textFromValue: function(v) { return (v/10).toFixed(1) }
            valueFromText: function(t) { return Math.round(parseFloat(t)*10) }
        }
        QQC2.Label { text: "  (0.5 dark-biased · 1.0 linear · 2.0 bright-biased)"; opacity:0.7; font.pointSize: Kirigami.Theme.smallFont.pointSize }
    }
}
