import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root

    // ── Plasma integration ───────────────────────────────────────────────────
    preferredRepresentation: compactRepresentation
    Plasmoid.icon: "video-display-brightness"
    Plasmoid.toolTipMainText: "Wireless Light Sensor"
    Plasmoid.toolTipSubText: statusCode === 2
        ? currentLux.toFixed(0) + " lux → " + currentBright + "%"
        : statusCode === 1 ? "Phone not connected"
        : "Daemon not running"

    // ── Live state (polled from WLS daemon HTTP API) ─────────────────────────
    property bool   sensorConnected: false
    property real   currentLux:      0
    property int    currentBright:   50
    property bool   autoEnabled:     true
    property bool   nightMode:       false
    property string phoneIp:         ""
    property string target:          "all"
    property var    displays:        []
    property string backend:         "—"
    property int    statusCode:      0   // 0=no daemon  1=daemon,no phone  2=ok

    // Lux history for sparkline
    property var luxHistory: []

    // ── HTTP API base ────────────────────────────────────────────────────────
    readonly property string apiBase: "http://127.0.0.1:29731"

    function apiGet(path, cb) {
        var xhr = new XMLHttpRequest()
        xhr.open("GET", apiBase + path)
        xhr.timeout = 1000
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status === 200) {
                try { cb(JSON.parse(xhr.responseText), null) }
                catch(e) { cb(null, e.toString()) }
            } else {
                cb(null, "HTTP " + xhr.status)
            }
        }
        xhr.onerror   = function() { cb(null, "network error") }
        xhr.ontimeout = function() { cb(null, "timeout") }
        xhr.send()
    }

    function apiPost(path, data) {
        var xhr = new XMLHttpRequest()
        xhr.open("POST", apiBase + path)
        xhr.setRequestHeader("Content-Type", "application/json")
        xhr.send(JSON.stringify(data))
    }

    // ── Poll every 2 s ───────────────────────────────────────────────────────
    Timer {
        interval: 2000; running: true; repeat: true
        onTriggered: {
            apiGet("/status", function(data, err) {
                if (err || !data) {
                    root.statusCode = 0; return
                }
                root.sensorConnected = data.connected  || false
                root.currentLux      = data.lux        || 0
                root.currentBright   = data.brightness || 50
                root.autoEnabled     = data.enabled
                root.nightMode       = data.night_mode
                root.phoneIp         = data.phone_ip   || ""
                root.target          = data.target     || "all"
                root.displays        = data.displays   || []
                root.backend         = data.backend    || "—"
                root.statusCode      = data.connected  ? 2 : 1

                // Update sparkline history
                var h = root.luxHistory.slice()
                h.push(data.lux || 0)
                if (h.length > 40) h.shift()
                root.luxHistory = h
                sparkCanvas.requestPaint()
            })
        }
    }

    // ── Compact view (panel icon) ────────────────────────────────────────────
    compactRepresentation: MouseArea {
        onClicked: root.expanded = !root.expanded

        implicitWidth: compactRow.implicitWidth + Kirigami.Units.smallSpacing * 2

        RowLayout {
            id: compactRow
            anchors.centerIn: parent
            spacing: 4

            // Connection dot
            Rectangle {
                width: 7; height: 7; radius: 4
                color: root.statusCode === 2 ? "#2ecc71"
                     : root.statusCode === 1 ? "#f39c12" : "#e74c3c"
            }

            // Icon
            Kirigami.Icon {
                source: root.nightMode          ? "weather-clear-night-symbolic"
                      : root.currentBright > 66 ? "brightness-high-symbolic"
                      : root.currentBright > 33 ? "brightness-medium-symbolic"
                      :                           "brightness-low-symbolic"
                implicitWidth:  Kirigami.Units.iconSizes.small
                implicitHeight: Kirigami.Units.iconSizes.small
            }

            // Percent
            PlasmaComponents.Label {
                text: root.statusCode === 0 ? "WLS" : (root.currentBright + "%")
                font.pixelSize: 12
                font.bold: true
            }
        }
    }

    // ── Full popup ───────────────────────────────────────────────────────────
    fullRepresentation: Item {
        Layout.preferredWidth:  320
        Layout.preferredHeight: popupCol.implicitHeight + Kirigami.Units.largeSpacing * 2

        ColumnLayout {
            id: popupCol
            anchors { fill: parent; margins: Kirigami.Units.largeSpacing }
            spacing: Kirigami.Units.largeSpacing

            // ── Title bar ────────────────────────────────────────────────────
            RowLayout {
                Layout.fillWidth: true
                Kirigami.Icon {
                    source: "video-display-brightness"
                    implicitWidth:  Kirigami.Units.iconSizes.medium
                    implicitHeight: Kirigami.Units.iconSizes.medium
                }
                ColumnLayout {
                    spacing: 0
                    PlasmaComponents.Label {
                        text: "Wireless Light Sensor"
                        font.bold: true
                    }
                    PlasmaComponents.Label {
                        text: root.statusCode === 0 ? "⚠ Daemon not running"
                            : root.statusCode === 1 ? "⚠ Phone not connected  (" + root.phoneIp + ")"
                            : "● " + root.phoneIp + "  [" + root.target + "]"
                        font.pointSize: Kirigami.Theme.smallFont.pointSize
                        color: root.statusCode === 2
                            ? Kirigami.Theme.positiveTextColor
                            : Kirigami.Theme.neutralTextColor
                        elide: Text.ElideRight
                        Layout.fillWidth: true
                    }
                }
                Item { Layout.fillWidth: true }
                PlasmaComponents.ToolButton {
                    icon.name: "configure"
                    onClicked: plasmoid.internalAction("configure").trigger()
                    QQC2.ToolTip.text: "Settings"; QQC2.ToolTip.visible: hovered
                }
            }

            Kirigami.Separator { Layout.fillWidth: true }

            // ── Stats grid ───────────────────────────────────────────────────
            GridLayout {
                columns: 2; Layout.fillWidth: true
                columnSpacing: Kirigami.Units.largeSpacing
                rowSpacing:    Kirigami.Units.smallSpacing

                PlasmaComponents.Label { text: "Ambient light"; opacity: 0.65; font.pointSize: Kirigami.Theme.smallFont.pointSize }
                PlasmaComponents.Label {
                    text: root.statusCode === 2 ? root.currentLux.toFixed(0) + " lux" : "—"
                    font.bold: true
                }

                PlasmaComponents.Label { text: "Brightness"; opacity: 0.65; font.pointSize: Kirigami.Theme.smallFont.pointSize }
                PlasmaComponents.Label { text: root.currentBright + "%"; font.bold: true }

                PlasmaComponents.Label { text: "Display"; opacity: 0.65; font.pointSize: Kirigami.Theme.smallFont.pointSize }
                PlasmaComponents.Label {
                    text: root.target === "all"      ? "All displays"
                        : root.target === "display0" ? "display0 (NVIDIA)"
                        : root.target === "display1" ? "display1 (Built-in)"
                        : root.target
                    font.pointSize: Kirigami.Theme.smallFont.pointSize
                }

                PlasmaComponents.Label { text: "Backend"; opacity: 0.65; font.pointSize: Kirigami.Theme.smallFont.pointSize }
                PlasmaComponents.Label { text: root.backend; font.pointSize: Kirigami.Theme.smallFont.pointSize; opacity: 0.8 }
            }

            Kirigami.Separator { Layout.fillWidth: true }

            // ── Brightness slider ────────────────────────────────────────────
            ColumnLayout {
                Layout.fillWidth: true; spacing: 4

                RowLayout {
                    PlasmaComponents.Label { text: "Brightness"; font.bold: true }
                    Item { Layout.fillWidth: true }
                    PlasmaComponents.Label {
                        text: brightnessSlider.value + "%"
                        font.bold: true
                        color: Kirigami.Theme.highlightColor
                    }
                }

                QQC2.Slider {
                    id: brightnessSlider
                    Layout.fillWidth: true
                    from: 1; to: 100; stepSize: 1
                    value: root.currentBright
                    enabled: root.statusCode > 0

                    onMoved: {
                        root.apiPost("/brightness", {
                            value: Math.round(value),
                            target: root.target
                        })
                    }
                }

                RowLayout {
                    PlasmaComponents.Label { text: "🌑"; opacity: 0.5 }
                    Item { Layout.fillWidth: true }
                    PlasmaComponents.Label { text: "☀️"; opacity: 0.9 }
                }
            }

            Kirigami.Separator { Layout.fillWidth: true }

            // ── Toggle buttons ───────────────────────────────────────────────
            RowLayout {
                Layout.fillWidth: true; spacing: Kirigami.Units.smallSpacing

                PlasmaComponents.Button {
                    Layout.fillWidth: true
                    icon.name: root.autoEnabled ? "media-playback-pause" : "media-playback-start"
                    text: root.autoEnabled ? "Auto  ON" : "Auto  OFF"
                    highlighted: root.autoEnabled
                    enabled: root.statusCode > 0
                    onClicked: {
                        root.autoEnabled = !root.autoEnabled
                        root.apiPost("/set", {key:"enabled", value:root.autoEnabled})
                    }
                }

                PlasmaComponents.Button {
                    Layout.fillWidth: true
                    icon.name: "weather-clear-night"
                    text: root.nightMode ? "Night  ON" : "Night  OFF"
                    highlighted: root.nightMode
                    enabled: root.statusCode > 0
                    onClicked: {
                        root.nightMode = !root.nightMode
                        root.apiPost("/set", {key:"night_mode", value:root.nightMode})
                    }
                }
            }

            // ── Lux sparkline ────────────────────────────────────────────────
            ColumnLayout {
                Layout.fillWidth: true; spacing: 4
                visible: root.statusCode === 2

                PlasmaComponents.Label {
                    text: "Lux history"
                    font.pointSize: Kirigami.Theme.smallFont.pointSize
                    opacity: 0.6
                }

                Canvas {
                    id: sparkCanvas
                    Layout.fillWidth: true
                    height: 36

                    onPaint: {
                        var ctx = getContext("2d")
                        var w = width, h = height
                        ctx.clearRect(0, 0, w, h)
                        var hist = root.luxHistory
                        if (hist.length < 2) return

                        var maxV = 1
                        for (var i = 0; i < hist.length; i++)
                            if (hist[i] > maxV) maxV = hist[i]

                        var step = w / (hist.length - 1)
                        var hc   = Kirigami.Theme.highlightColor

                        ctx.beginPath()
                        ctx.strokeStyle = Qt.rgba(hc.r, hc.g, hc.b, 1.0)
                        ctx.lineWidth   = 1.5
                        ctx.moveTo(0, h - (hist[0]/maxV)*h)
                        for (var j = 1; j < hist.length; j++)
                            ctx.lineTo(j*step, h - (hist[j]/maxV)*h)
                        ctx.stroke()

                        // Area fill
                        ctx.lineTo((hist.length-1)*step, h)
                        ctx.lineTo(0, h)
                        ctx.closePath()
                        ctx.fillStyle = Qt.rgba(hc.r, hc.g, hc.b, 0.12)
                        ctx.fill()
                    }
                }
            }

            // ── Daemon warning ───────────────────────────────────────────────
            Kirigami.InlineMessage {
                Layout.fillWidth: true
                type:    Kirigami.MessageType.Warning
                visible: root.statusCode === 0
                text:    "WLS daemon is not running.\n" +
                         "Start: systemctl --user start WLS"
            }

            Item { Layout.fillHeight: true }
        }
    }
}
